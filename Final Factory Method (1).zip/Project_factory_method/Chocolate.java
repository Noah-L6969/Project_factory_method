public interface Chocolate
{
    void create();
}
