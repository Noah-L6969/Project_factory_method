public class FactoryGUIDemo
{
	/**
     * Runs the demo.
     * 
     * @param args command line arguments
     */
    public static void main(String[] args) 
    {
        App app = new App();
    }
}