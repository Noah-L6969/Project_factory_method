public interface Wrapper
{
    void wrap();
}
