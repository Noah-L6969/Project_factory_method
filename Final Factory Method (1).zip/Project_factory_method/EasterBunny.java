public class EasterBunny implements Chocolate
 {

    @Override
    public void create() 
    {
        System.out.println("Collecting chocolate bunnies...");
    }
    
}
