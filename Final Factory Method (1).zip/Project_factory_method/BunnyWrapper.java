public class BunnyWrapper implements Wrapper {

    @Override
    public void wrap() {
        System.out.println("Wrapping in bunny-themed foil...");
    }

}
