public class ReeseWrapper implements Wrapper {

    @Override
    public void wrap() {
        System.out.println("Wrapping in Reese's branded wrapper...");
    }

}
